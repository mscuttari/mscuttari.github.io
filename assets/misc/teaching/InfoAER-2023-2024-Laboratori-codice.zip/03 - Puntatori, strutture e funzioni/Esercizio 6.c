#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_L 100

typedef struct {
    char* titolo;
    char* autore;
} libro_t;

typedef struct {
    libro_t* libri;
    int num_libri;
    int max_libri;
} catalogo_t;

enum Azione {AGGIUNGI_LIBRO = 1, CERCA_PER_TITOLO, ESCI};

int gestisci_scelta(catalogo_t* catalogo, int scelta);
char* leggi_stringa(char* buffer);
int leggi_libro(catalogo_t* catalogo);
int cerca_per_titolo(catalogo_t* catalogo);
void distruggi_catalogo(catalogo_t* catalogo);

int main() {
    catalogo_t catalogo = {NULL, 0, 0};

    printf("Inserire il numero massimo di libri: ");
    scanf("%d", &catalogo.max_libri);

    catalogo.libri = (libro_t*) malloc(catalogo.max_libri * sizeof(libro_t));

    if (catalogo.libri == NULL) {
        return -1;
    }

    int scelta;

    do {
        printf("%d. Aggiungi libro.\n", AGGIUNGI_LIBRO);
        printf("%d. Cerca per titolo.\n", CERCA_PER_TITOLO);
        printf("%d. Esci\n", ESCI);

        scanf("%d", &scelta);
    } while (gestisci_scelta(&catalogo, scelta));

    // Deallocazione della memoria.
    distruggi_catalogo(&catalogo);

    return 0;
}

int gestisci_scelta(catalogo_t* catalogo, int scelta) {
    switch (scelta) {
        case AGGIUNGI_LIBRO:
            return leggi_libro(catalogo);

        case CERCA_PER_TITOLO:
            return cerca_per_titolo(catalogo);

        case ESCI:
            return 0;

        default:
            printf("Scelta non valida.\n");
            return 0;
    }
}

char* leggi_stringa(char* buffer) {
    scanf(" %[^\n]%*c", buffer);

    char* ris = (char*) malloc((strlen(buffer) + 1) * sizeof(char));

    if (ris != NULL) {
        strcpy(ris, buffer);
    }

    return ris;
}

int leggi_libro(catalogo_t* catalogo) {
    char buffer[BUFFER_L];

    if (catalogo->num_libri == catalogo->max_libri) {
        printf("Raggiunto il numero massimo di libri.\n");
        return 1;
    }

    libro_t* libro = catalogo->libri + catalogo->num_libri;

    printf("Inserire il titolo: ");
    libro->titolo = leggi_stringa(buffer);

    printf("Inserire l'autore: ");
    libro->autore = leggi_stringa(buffer);

    if (libro->titolo != NULL && libro->autore != NULL) {
        catalogo->num_libri++;
        return 1;
    }

    return 0;
}

int cerca_per_titolo(catalogo_t* catalogo) {
    char buffer[BUFFER_L];

    printf("Inserire il titolo da cercare: ");
    scanf(" %[^\n]%*c", buffer);

    for (int i = 0; i < catalogo->num_libri; ++i) {
        libro_t* libro = catalogo->libri + i;

        if (strcmp(libro->titolo, buffer) == 0) {
            printf("Libro n. %d\n", i + 1);
            printf("Titolo: %s\n", libro->titolo);
            printf("Autore: %s\n", libro->autore);
        }
    }

    return 1;
}

void distruggi_catalogo(catalogo_t* catalogo) {
    for (int i = 0; i < catalogo->num_libri; ++i) {
        libro_t* libro = catalogo->libri + i;

        if (libro->titolo != NULL) {
            free(catalogo->libri[i].titolo);
        }

        if (libro->autore != NULL) {
            free(catalogo->libri[i].autore);
        }
    }

    free(catalogo->libri);
}
