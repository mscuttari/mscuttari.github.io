#include <stdio.h>
#include <math.h>

int calcola_soluzioni(float a, float b, float c,
                      float* x1, float* x2);

int main() {
    float a, b, c;

    scanf("%f%f%f",&a, &b, &c);

    float x1, x2;
    int reali = calcola_soluzioni(a, b, c, &x1, &x2);

    if (reali) {
        if (x1 == x2) {
            printf("%f\n", x1);
        } else if (x1 < x2) {
            printf("%f\n%f\n", x1, x2);
        } else {
            printf("%f\n%f\n", x2, x1);
        }
    } else {
        printf("-\n");
    }

    return 0;
}

int calcola_soluzioni(float a, float b, float c, float* x1, float* x2) {
    // Calcoliamo il delta: b^2 - 4ac
    float delta = b*b - 4*a*c;

    if (delta < 0) {
        // Soluzioni immaginarie.
        return 0;
    }

    // Soluzione 1: (-b + sqrt(delta)) / 2a
    *x1 = (-b + sqrt(delta)) / (2 * a);
    
    // Soluzione 2: (-b - sqrt(delta)) / 2a
    *x2 = (-b - sqrt(delta)) / (2 * a);

    return 1;
}
