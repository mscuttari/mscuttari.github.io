#include <stdio.h>

typedef struct {
    int h;
    int m;
    int s;
} orario_t;

orario_t leggi_orario();
int orario_valido(orario_t orario);
int secondi_da_mezzanotte(orario_t orario);

int main() {
    printf("Inserire il primo orario (hh:mm:ss):\n");
    orario_t orario1 = leggi_orario();

    printf("Inserire il secondo orario (hh:mm:ss):\n");
    orario_t orario2 = leggi_orario();

    int s1 = secondi_da_mezzanotte(orario1);
    int s2 = secondi_da_mezzanotte(orario2);

    int ris = s1 > s2 ? s1 - s2 : s2 - s1;
    printf("Secondi tra i due orari: %d\n", ris);

    return 0;
}

orario_t leggi_orario() {
    orario_t orario;

    do {
        scanf("%d:%d:%d", &orario.h, &orario.m, &orario.s);

        if (!orario_valido(orario)) {
            printf("Orario non valido. Inserire nuovamente.\n");
        }
    } while (!orario_valido(orario));

    return orario;
}

int orario_valido(orario_t orario) {
    return orario.h >= 0 && orario.h <= 23 & orario.m >= 0 && orario.m <= 59 && orario.s >= 0 && orario.s <= 59;
}

int secondi_da_mezzanotte(orario_t orario) {
    return orario.s + 60 * orario.m + 3600 * orario.h;
}
