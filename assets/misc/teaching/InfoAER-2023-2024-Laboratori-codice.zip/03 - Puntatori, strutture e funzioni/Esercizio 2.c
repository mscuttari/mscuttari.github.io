#include <stdio.h>

#define N 10

void leggi_array(int* v, int n);
void scambia_array(int* v1, int* v2, int n);
void stampa_array(int* v, int n);

int main() {
    int v1[N], v2[N];

    leggi_array(v1, N);
    leggi_array(v2, N);

    scambia_array(v1, v2, N);

    stampa_array(v1, N);
    stampa_array(v2, N);

    return 0;
}

void leggi_array(int* v, int n) {
    for (int i = 0; i < n; ++i) {
        scanf("%d", &v[i]);
    }
}

void scambia_array(int* v1, int* v2, int n) {
    for (int i = 0; i < n; ++i) {
        int tmp = v1[i];
        v1[i] = v2[i];
        v2[i] = tmp;
    }
}

void stampa_array(int* v, int n) {
    for (int i = 0; i < n; ++i) {
        printf("%d ", v[i]);
    }

    printf("\n");
}
