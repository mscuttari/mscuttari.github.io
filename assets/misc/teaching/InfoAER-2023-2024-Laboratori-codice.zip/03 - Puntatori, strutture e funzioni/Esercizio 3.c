#include <stdio.h>
#include <math.h>

typedef struct {
    float x;
    float y;
} punto_t;

typedef struct {
    float m;
    float q;
} retta_t;

punto_t leggi_punto();
retta_t calcola_retta(punto_t p1, punto_t p2);

int main() {
    punto_t p1 = leggi_punto();
    punto_t p2 = leggi_punto();
    
    // Si assume che i due punti non siano coincidenti.
    // Possibile estensione: gestire anche il caso in cui invece lo siano.
    retta_t r = calcola_retta(p1, p2);

    if (r.m == INFINITY) {
        printf("x = %f\n", r.q);
    } else if (r.m == 0) {
        printf("y = %f\n", r.q);
    } else {
        printf("y = %f * x + %f\n", r.m ,r.q);
    }

    return 0;
}

punto_t leggi_punto() {
    punto_t p;
    scanf("(%f,%f)%*c", &p.x, &p.y);
    return p;
}

retta_t calcola_retta(punto_t p1, punto_t p2) {
    retta_t ris;

    if (p1.x == p2.x) {
        // x = q
        ris.m = INFINITY;
        ris.q = p1.x;
    } else {
        // y = mx + q
        ris.m = (p2.y - p1.y) / (p2.x - p1.x);

        // y2 = m * x2 + q
        // q = -(m * x2) + y2
        ris.q = -(ris.m * p2.x) + p2.y;
    }

    return ris;
}
