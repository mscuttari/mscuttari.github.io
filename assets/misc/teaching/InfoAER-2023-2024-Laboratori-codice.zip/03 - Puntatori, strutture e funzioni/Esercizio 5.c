#include <stdio.h>
#include <math.h>

typedef struct {
    float r;
    float i;
} complesso_t;

void calcola_soluzioni(float a, float b, float c, complesso_t* x1, complesso_t* x2);
void stampa_complesso(complesso_t c);

int main() {
    float a, b, c;
    scanf("%f%f%f", &a, &b, &c);

    complesso_t x1, x2;
    calcola_soluzioni(a, b, c, &x1, &x2);

    if (x1.r == x2.r) {
        if (x1.i < x2.i) {
            stampa_complesso(x1);
            printf("\n");
            stampa_complesso(x2);
        } else {
            stampa_complesso(x2);
            printf("\n");
            stampa_complesso(x1);
        }
    } else if (x1.r < x2.r) {
        stampa_complesso(x1);
        printf("\n");
        stampa_complesso(x2);
    } else {
        stampa_complesso(x2);
        printf("\n");
        stampa_complesso(x1);
    }

    return 0;
}

void calcola_soluzioni(float a, float b, float c, complesso_t* x1, complesso_t* x2) {
    float delta = b*b - 4*a*c;

    if (delta >= 0) {
        x1->r = (-b + sqrt(delta)) / (2 * a);
        x1->i = 0;
        x2->r = (-b - sqrt(delta)) / (2 * a);
        x2->i = 0;
    } else {
        x1->r = -b / (2*a);
        x1->i = sqrt(-delta) / (2 * a);

        x2->r = -b / (2*a);
        x2->i = -sqrt(-delta) / (2 * a);
    }
}

void stampa_complesso(complesso_t c) {
    printf("%f", c.r);

    if (c.i != 0) {
        if (c.i > 0)
            printf(" + i%f", c.i);
        else
            printf(" - i%f", -c.i);
    }
}
