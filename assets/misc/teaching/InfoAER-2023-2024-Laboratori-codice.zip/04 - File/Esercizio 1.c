#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_RIGA 200
#define MAX_PAROLA 25

char* trovaParolaPiuLunga(FILE* f);

int main() {
    char nomeFile[200];
    scanf("%s", nomeFile);

    FILE* f = fopen(nomeFile, "r");

    if (f == NULL) {
        return 0;
    }

    char* parola = trovaParolaPiuLunga(f);

    if (parola != NULL) {
        printf("%s\n", parola);
        free(parola);
    }

    fclose(f);
    return 0;
}

char* trovaParolaPiuLunga(FILE* f) {
    char* risultato = (char*) malloc((MAX_PAROLA + 1) * sizeof(char));

    if (risultato == NULL) {
        return NULL;
    }

    risultato[0] = '\0';
    char riga[MAX_RIGA + 2];

    while (fgets(riga, MAX_RIGA + 2, f) != NULL) {
        char* parola = strtok(riga, ";,.'\"<>\n\t ");

        while (parola != NULL) {
            if (strlen(parola) >= strlen(risultato)) {
                strcpy(risultato, parola);
            }

            parola = strtok(NULL, ";,.'\"<>\n\t ");
        }
    }

    return risultato;
}