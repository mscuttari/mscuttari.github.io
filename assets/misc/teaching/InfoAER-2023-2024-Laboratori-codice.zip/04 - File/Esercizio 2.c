#include <stdio.h>

#define MAX_NOME 20
#define MAX_COGNOME 20
#define MAX_ALUNNI 30

typedef struct {
    int giorno;
    int mese;
    int anno;
} data_t;

typedef struct {
    char nome[MAX_NOME];
    char cognome[MAX_COGNOME];
    float altezza;
    data_t data_di_nascita;
} alunno_t;

int leggi_classe(FILE* f, alunno_t* alunni);

int main() {
    char nomeFile[200];
    scanf("%s", nomeFile);
    FILE* f = fopen(nomeFile, "r");

    if (f == NULL) {
        return 0;
    }

    alunno_t alunni[MAX_ALUNNI];
    int n = leggi_classe(f, alunni);
    float altezza_media = 0;

    for (int i = 0; i < n; ++i) {
        altezza_media += alunni[i].altezza;
    }

    if (n != 0) {
        altezza_media /= n;

        for (int i = 0; i < n; ++i) {
            if (alunni[i].altezza > altezza_media) {
                printf("%s %s\n", alunni[i].nome, alunni[i].cognome);
            }
        }
    }

    fclose(f);
    return 0;
}

int leggi_classe(FILE* f, alunno_t* alunni) {
    int n = 0;

    while (fscanf(f, "%[^;];%[^;];%f;%d;%d;%d\n",
                  alunni[n].nome,
                  alunni[n].cognome,
                  &alunni[n].altezza,
                  &alunni[n].data_di_nascita.giorno,
                  &alunni[n].data_di_nascita.mese,
                  &alunni[n].data_di_nascita.anno) == 6) {
        n++;
    }

    return n;
}
