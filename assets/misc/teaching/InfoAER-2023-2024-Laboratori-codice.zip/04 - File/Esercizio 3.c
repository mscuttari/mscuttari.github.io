#include <stdio.h>
#include <stdlib.h>

typedef struct {
    float acidita_fissa;
    float acidita_volatile;
    float acido_citrico;
    float residuo_zuccherino;
    float cloruri;
    float anidride_solforosa_libera;
    float anidride_solforosa_totale;
    float densita;
    float ph;
    float solfati;
    float gradazione;
    int qualita;
} vino_t;

typedef struct {
    vino_t* vini;
    int numero_vini;
} catalogo_t;

int numero_righe(FILE* f);
catalogo_t leggi_catalogo(FILE* f);

int main() {
    char nomeFile[500];
    scanf("%s", nomeFile);

    FILE* f = fopen(nomeFile, "r");

    if (f == NULL) {
        return 0;
    }

    catalogo_t catalogo = leggi_catalogo(f);

    if (catalogo.vini != NULL) {
        int buoni = 0;
        float gradazione_media = 0;

        for (int i = 0; i < catalogo.numero_vini; ++i) {
            if (catalogo.vini[i].qualita >= 6) {
                buoni++;
                gradazione_media += catalogo.vini[i].gradazione;
            }
        }

        if (buoni == 0) {
            printf("-\n");
        } else {
            gradazione_media /= buoni;
            printf("%f\n", gradazione_media);
        }

        free(catalogo.vini);
    }

    fclose(f);
    return 0;
}

int numero_righe(FILE* f) {
    int righe = 0;
    char c;

    rewind(f);

    while ((c = getc(f)) != EOF) {
        if (c == '\n') {
            righe++;
        }
    }

    return righe;
}

catalogo_t leggi_catalogo(FILE* f) {
    catalogo_t catalogo;
    catalogo.numero_vini = numero_righe(f) - 1;

    rewind(f);
    fscanf(f, "%*[^\n]");

    catalogo.vini = (vino_t*) malloc((catalogo.numero_vini) * sizeof(vino_t));

    if (catalogo.vini == NULL) {
        return catalogo;
    }

    for (int i = 0; i < catalogo.numero_vini; ++i) {
        int parametri_letti = fscanf(f, "%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%d\n",
                                     &catalogo.vini[i].acidita_fissa,
                                     &catalogo.vini[i].acidita_volatile,
                                     &catalogo.vini[i].acido_citrico,
                                     &catalogo.vini[i].residuo_zuccherino,
                                     &catalogo.vini[i].cloruri,
                                     &catalogo.vini[i].anidride_solforosa_libera,
                                     &catalogo.vini[i].anidride_solforosa_totale,
                                     &catalogo.vini[i].densita,
                                     &catalogo.vini[i].ph,
                                     &catalogo.vini[i].solfati,
                                     &catalogo.vini[i].gradazione,
                                     &catalogo.vini[i].qualita);

        if (parametri_letti != 12) {
            // Errore di lettura.
            // Stop, e riduzione del numero di vini del catalogo.

            catalogo.numero_vini = i;
            break;
        }
    }

    return catalogo;
}
