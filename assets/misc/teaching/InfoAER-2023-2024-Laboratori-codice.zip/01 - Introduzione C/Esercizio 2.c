#include <stdio.h>
#include <math.h>

int main() {
    int n;
    int primo = 1;

    do {
        printf("inserire un numero intero positivo\n");
        scanf("%d", &n);
    } while (n <= 0);

    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) {
            // abbiamo trovato un divisore per n
            primo = 0;
            break;
        }
    }
    
    /*
     Versione equivalente con ciclo while invece del ciclo for:
    int i = 2;
     
    while(i <= sqrt(n)) {
        if (n % i == 0) {
            // abbiamo trovato un divisore per n
            primo = 0;
            break;
        }

        i++;
    }
     */

    if (primo == 1) {
        printf("il numero e' primo");
    } else {
        printf("il numero non e' primo");
    }

    return 0;
}
