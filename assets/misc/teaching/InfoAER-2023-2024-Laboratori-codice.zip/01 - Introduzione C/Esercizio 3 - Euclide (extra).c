#include <stdio.h>

// Versione alternativa con calcolo del MCD tramite l'algoritmo di Euclide.
// Vedere qui per il suo funzionamento: https://it.wikipedia.org/wiki/Algoritmo_di_Euclide

int main() {
    int x, y;
    int a, b, r, mcd;

    do {
        scanf("%d%d", &x, &y);
    } while (x <= 0 || y <= 0);

    a = x;
    b = y;

    while (b != 0) {
        r = a % b;
        a = b;
        b = r;
    }

    mcd = a;

    if (mcd == 1) {
        printf("numeri coprimi\n");
    } else {
        printf("non coprimi\n");
    }

    return 0;
}
