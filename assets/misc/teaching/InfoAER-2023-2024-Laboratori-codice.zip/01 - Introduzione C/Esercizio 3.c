#include <stdio.h>

int main() {
    int x, y;
    int min;
    int coprimi = 1;

    do {
        scanf("%d%d", &x, &y);
    } while (x <= 0 || y <= 0);

    min = x < y ? x : y;

    for (int i = 2; i <= min && coprimi == 1; i++) {
        if (x % i == 0 && y % i == 0) {
            coprimi = 0;
        }
    }

    if (coprimi == 1) {
        printf("numeri coprimi\n");
    } else {
        printf("non coprimi\n");
    }

    return 0;
}
