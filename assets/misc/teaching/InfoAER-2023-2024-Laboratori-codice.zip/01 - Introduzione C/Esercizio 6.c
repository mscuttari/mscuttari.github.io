#include <stdio.h>

int main() {
    float capitale_iniziale, tasso_interesse;
    int durata;
    float capitale_investito, interessi, interessi_totali;

    printf("Inserire il capitale iniziale: ");
    scanf("%f", &capitale_iniziale);

    printf("Inserire il tasso di interesse annuo: ");
    scanf("%f", &tasso_interesse);

    printf("Inserire la durata dell'investimento (in anni): ");
    scanf("%d", &durata);

    capitale_investito = capitale_iniziale;

    for (int i = 1; i <= durata; ++i) {
        interessi = capitale_investito * tasso_interesse / 100;
        capitale_investito += interessi * 0.7;
        interessi_totali += interessi;

        printf("[Anno %d]\t", i);
        printf("Interessi totali: %.2f€\t", interessi_totali);

        if (i != durata)
            printf("Capitale investito: %.2f", capitale_investito);

        printf("\n");
    }

    return 0;
}
