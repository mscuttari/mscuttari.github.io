#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N_MAX 100

int main() {
    float n;
    int casuale, n;
    srand(time(0));
    casuale = rand() % (N_MAX + 1);

    do {
        scanf("%d", &n);

        if (n > casuale) {
            printf("numero troppo grande\n");
        } else if (n < casuale) {
            printf("numero troppo piccolo\n");
        }
    } while (n != casuale);

    printf("numero indovinato\n");

    return 0;
}
