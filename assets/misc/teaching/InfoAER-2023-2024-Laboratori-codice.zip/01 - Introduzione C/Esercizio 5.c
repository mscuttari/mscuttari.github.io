#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MIN 1
#define MAX 100

int main() {
    int numero_assegnato, numero_bonus, gratis = 0, pagati = 0;
    float prezzo, totale_gratis = 0, totale_pagati = 0, media_pagati = 0;

    srand(time(0));
    numero_assegnato = rand() % (MAX - MIN + 1) + MIN;

    do {
        scanf("%f", &prezzo);

        if (prezzo != 0) {
            numero_bonus = rand() % (MAX - MIN + 1) + MIN;
            if (numero_assegnato == numero_bonus) {
                totale_gratis += prezzo;
                gratis++;
            } else {
                totale_pagati += prezzo;
                pagati++;
            }
        }
    } while (prezzo > 0);

    if (pagati != 0)
        media_pagati = totale_pagati / pagati;

    if (totale_pagati > 300)
        totale_pagati *= 0.85;

    printf("Sono stati regalati %d prodotti per un valore totale di %.2f€\n", gratis, totale_gratis);
    printf("Il prezzo medio dei prodotti pagati è di %.2f€\n", media_pagati);
    printf("Totale spesa: %.2f\n", totale_pagati);

    return 1;
}
