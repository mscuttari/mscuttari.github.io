#include <stdio.h>
#include <math.h>

int main() {
    float a, b, c;
    int triangolo;
    float somma_opposti_a, somma_opposti_b, somma_opposti_c;

    do {
        printf("Inserire i tre lati:");
        scanf("%f%f%f", &a, &b, &c);
    } while (a <= 0 || b <= 0 || c <= 0);

    somma_opposti_a = b + c;
    somma_opposti_b = a + c;
    somma_opposti_c = a + b;

    if (a < somma_opposti_a && b < somma_opposti_b && c < somma_opposti_c) {
        triangolo = 1;
    } else {
        triangolo = 0;
    }

    if (triangolo == 1) {
        printf("e' un triangolo\n");

        if (a == b && b == c) {
            printf("equilatero\n");
        } else if (a == b || b == c || a == c) {
            printf("isoscele\n");
        } else {
            printf("scaleno\n");
        }

        if (b*b + c*c == a*a || a*a + b*b == c*c || a*a + c*c == b*b) {
            printf("rettangolo\n");
        }
    } else {
        printf("non e' un triangolo\n");
    }

    return 0;
}
