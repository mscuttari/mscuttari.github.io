#include <stdio.h>

#define MAX 100

int main() {
    char str[MAX];

    printf("Inserire una stringa: ");
    scanf("%s", str);

    int i = 0;
    int parentesi = 0;

    // L'idea è che finchè incontriamo '(' va tutto bene.
    // Se incontriamo ')', va bene solo se abbiamo delle '(' in sospeso.
    do {
        if (str[i] == '(') {
            parentesi++;
        } else if (str[i] == ')') {
            parentesi--;
        }
    } while (str[i++] != '\0' && parentesi >= 0);

    // Alla fine bisogna però controllare se sono rimaste delle '(' non chiuse.
    if (parentesi == 0) {
        printf("La stringa è ben parentesizzata");
    } else {
        printf("La stringa non è ben parentesizzata");
    }

    return 0;
}
