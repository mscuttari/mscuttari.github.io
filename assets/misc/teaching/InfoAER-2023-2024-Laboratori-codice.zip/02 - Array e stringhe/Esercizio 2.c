#include <stdio.h>

#define N 10

int main() {
    int valori[N];
    int soglia;

    for (int i = 0; i < N; ++i) {
        printf("Inserire un valore (%d di %d): ", i + 1, N);
        scanf("%d", &valori[i]);
    }

    printf("Inserire la soglia: ");
    scanf("%d", &soglia);
    
    int lunghezza_max = 0;
    int lunghezza_corrente = 0;

    if (valori[0] > soglia) {
        lunghezza_corrente++;
        lunghezza_max = lunghezza_corrente;
    }

    for (int i = 1; i < N; ++i) {
        if (valori[i] <= soglia) {
            // Resettiamo a 0 la lunghezza della sequenza corrente, in quanto il valore corrente non appartiene a una sequenza valida (è minore della soglia).
            lunghezza_corrente = 0;
        } else  {
            // Se invece il valore è sopra la soglia, vediamo se la sequenza precedente continua o no.
            if (valori[i] > valori[i - 1]) {
                lunghezza_corrente++;

                if (lunghezza_corrente > lunghezza_max) {
                    lunghezza_max = lunghezza_corrente;
                }
            } else {
                lunghezza_corrente = 1;
            }
        }
    }

    printf("Massima lunghezza: %d\n", lunghezza_max);

    return 0;
}
