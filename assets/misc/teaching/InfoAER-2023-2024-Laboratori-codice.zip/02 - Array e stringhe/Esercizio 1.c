#include <stdio.h>

#define N 5

int main() {
    int v1[N];
    int v2[N];
    int risultato[N + N];

    printf("Inserire i valori del primo array.\n");

    for (int i = 0; i < N; ++i) {
        printf("Inserire un numero intero (%d di %d): ", i + 1, N);
        scanf("%d", &v1[i]);
    }

    printf("Inserire i valori del secondo array.\n");

    for (int i = 0; i < N; ++i) {
        printf("Inserire un numero intero (%d di %d): ", i + 1, N);
        scanf("%d", &v2[i]);
    }

    for (int i = 0; i < N; ++i) {
        risultato[i * 2] = v1[i];
    }

    for (int i = 0; i < N; ++i) {
        risultato[i * 2 + 1] = v2[N - i - 1];
    }

    for (int i = 0; i < N + N; ++i) {
        printf("%d\t", risultato[i]);
    }

    return 0;
}
