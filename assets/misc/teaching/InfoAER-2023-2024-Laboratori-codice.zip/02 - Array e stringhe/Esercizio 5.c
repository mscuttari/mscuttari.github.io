#include <stdio.h>
#include <string.h>

#define MAX_STRINGA 100
#define MAX_ERRORI 5

int main() {
    char segreto[MAX_STRINGA];
    char str[MAX_STRINGA];
    char c;
    int lettere_trovate = 0;
    int errori = 0;

    printf("Inserire la parola da indovinare: ");
    scanf("%s%*c", segreto);

    for (int i = 0; i < MAX_STRINGA - 1; ++i) {
        str[i] = '_';
    }

    str[MAX_STRINGA - 1] = '\0';
    int len = strlen(segreto);

    for (int i = 0; i < len; ++i) {
        printf("%c ", str[i]);
    }

    printf("\n\n");

    while (lettere_trovate != len && errori < MAX_ERRORI) {
        printf("Inserire una lettera: ");
        scanf("%c%*c", &c);

        int presente = 0;

        for (int i = 0; i < len; ++i) {
            if (segreto[i] == c) {
                str[i] = c;
                presente = 1;
            }
        }
        
        if (!presente) {
            printf("Errore (%d di %d)!\n", ++errori, MAX_ERRORI);
        }

        for (int i = 0; i < len; ++i) {
            printf("%c ", str[i]);
        }

        printf("\n\n");
        
        lettere_trovate = 0;
        
        for (int i = 0; i < len; ++i) {
            if (segreto[i] == str[i]) {
                lettere_trovate++;
            }
        }
    }

    if (lettere_trovate == len) {
        printf("Hai vinto!\n");
    } else if (errori >= MAX_ERRORI) {
        printf("Hai perso!\n");
    }

    return 0;
}
