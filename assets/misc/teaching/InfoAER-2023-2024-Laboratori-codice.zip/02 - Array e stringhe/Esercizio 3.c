#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5

int main() {
    int m[N][N];

    srand(time(0));

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            m[i][j] = rand() % 50 + 1;
        }
    }

    printf("Matrice:\n");

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            printf("%d\t", m[i][j]);
        }

        printf("\n");
    }

    printf("\nSomme diagonali:\n");
    
    // Prima metà, ossia le sottomatrici che partono dall'angolo in basso a sinistra e man mano crescono verso verso la diagonale principale.
    for (int i = 0; i < N - 1; ++i) {
        int somma = 0;

        for (int j = 0; j < i + 1; ++j) {
            for (int k = 0; k < i + 1; ++k) {
                if (j == k) {
                    // La colonna è corretta, dato che le sottomatrici crescono partendo dal lato sinistro della matrice complessiva.
                    // Per la riga bisogna contare quante ce ne sono, nella matrice complessiva, prima dell'inizio della sottomatrice corrente (N - i - 1).
                    somma += m[j + N - i - 1][k];
                }
            }
        }

        printf("%d\n", somma);
    }

    // Seconda metà, ossia le sottomatrici che partono dalla matrice complessiva e si riducono fino ad arrivare all'angolo in alto a destra.
    for (int i = 0; i < N; ++i) {
        int somma = 0;

        for (int j = 0; j < N - i; ++j) {
            for (int k = 0; k < N - i; ++k) {
                if (j == k) {
                    // La riga è corretta, dato che le sottomatrici hanno il bordo superiore in comune.
                    // Per la colonna bisogna contare quante ce ne sono, nella matrice complessiva, prima dell'inizio della sottomatrice corrente (i).
                    somma += m[j][k + i];
                }
            }
        }

        printf("%d\n", somma);
    }

    return 0;
}
