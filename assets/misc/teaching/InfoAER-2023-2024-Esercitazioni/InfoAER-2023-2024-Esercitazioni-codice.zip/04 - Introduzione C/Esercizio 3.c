#include <stdio.h>

int main() {
    int anno1, mese1, giorno1;
    int anno2, mese2, giorno2;

    // Chiedo le date.
    printf("Inserire la prima data (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &giorno1, &mese1, &anno1);

    printf("Inserire la seconda data (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &giorno2, &mese2, &anno2);

    // Controllo che la prima data sia valida.

    if (giorno1 < 1) {
        printf("Giorno della prima data non valido (valore inserito: %d)\n", giorno1);
        return -1;
    }

    if (mese1 < 1 || mese1 > 12) {
        printf("Mese della prima data non valido (valore inserito: %d)\n", mese1);
        return -1;
    }

    if ((mese1 == 1 || mese1 == 5 || mese1 == 7 || mese1 == 8 || mese1 == 10 || mese1 == 12) && giorno1 > 31) {
        printf("Il mese della prima data ha al massimo 31 giorni (valore inserito: %d)\n", giorno1);
        return -1;
    }

    if ((mese1 == 4|| mese1 == 6 || mese1 == 9 || mese1 == 11) && giorno1 > 30) {
        printf("Il mese della prima data ha al massimo 30 giorni (valore inserito: %d)\n", giorno1);
        return -1;
    }

    if (mese1 == 2) {
        if (anno1 % 4 != 0 && giorno1 > 28) {
            printf("Il mese della prima data ha al massimo 28 giorni (valore inserito: %d)\n", giorno1);
            return -1;
        } else if (anno1 % 4 == 0 && giorno1 > 29) {
            printf("Il mese della prima data ha al massimo 29 giorni (valore inserito: %d)\n", giorno1);
            return -1;
        }
    }

    // Controllo che la seconda data sia valida.

    if (giorno2 < 1) {
        printf("Giorno della seconda data non valido (valore inserito: %d)\n", giorno2);
        return -1;
    }

    if (mese2 < 1 || mese2 > 12) {
        printf("Mese della seconda data non valido (valore inserito: %d)\n", mese2);
        return -1;
    }

    if ((mese2 == 1 || mese2 == 5 || mese2 == 7 || mese2 == 8 || mese2 == 10 || mese2 == 12) && giorno2 > 31) {
        printf("Il mese della seconda data ha al massimo 31 giorni (valore inserito: %d)\n", giorno2);
        return -1;
    }

    if ((mese2 == 4|| mese2 == 6 || mese2 == 9 || mese2 == 11) && giorno2 > 30) {
        printf("Il mese della seconda data ha al massimo 30 giorni (valore inserito: %d)\n", giorno2);
        return -1;
    }

    if (mese2 == 2) {
        if (anno2 % 4 != 0 && giorno2 > 28) {
            printf("Il mese della seconda data ha al massimo 28 giorni (valore inserito: %d)\n", giorno2);
            return -1;
        } else if (anno2 % 4 == 0 && giorno2 > 29) {
            printf("Il mese della seconda data ha al massimo 29 giorni (valore inserito: %d)\n", giorno2);
            return -1;
        }
    }

    // Confronto le date.

    if (anno1 < anno2) {
        printf("La prima data precede la seconda\n");
    } else if (anno1 > anno2) {
        printf("La seconda data precede la prima\n");
    } else {
        if (mese1 < mese2) {
            printf("La prima data precede la seconda\n");
        } else if (mese1 > mese2) {
            printf("La seconda data precede la prima\n");
        } else {
            if (giorno1 < giorno2) {
                printf("La prima data precede la seconda\n");
            } else if (giorno1 > giorno2) {
                printf("La seconda data precede la prima\n");
            } else {
                printf("Le due date sono uguali\n");
            }
        }
    }

    return 0;
}
