#include <stdio.h>

int main() {
    int n;
    int ultimo, valore;

    // Variabile che verrà impostata a 0 se si incontra un numero uguale o più piccolo del precedente.
    int crescente = 1;

    // Chiedo il numero di valori da leggere.
    printf("Inserire il numero di valori da leggere: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        // Chiedo il prossimo valore.
        printf("Inserire un valore: ");
        scanf("%d", &valore);

        if (i != 0 && valore <= ultimo) {
            crescente = 0;
        }

        ultimo = valore;
    }

    if (crescente) {
        printf("Lista crescente\n");
    } else {
        // Nota: non è detto che la lista sia decrescente.
        printf("Lista non crescente\n");
    }

    return 0;
}
