#include <stdio.h>

#define STEP 3

int main() {
    // Dichiaro le variabili.
    unsigned char c, risultato;

    // Chiedo la lettera da convertire.
    printf("Inserire una lettera da convertire:\n");
    scanf("%c", &c);

    // Controllo la validità del carattere.
    if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) {
        printf("Lettera non valida!\n");
        return 1;
    }

    // Calcolo la lettera spostata di "STEP" posti in avanti.
    risultato = c + STEP % 26;

    // Considero la ciclicità dell'alfabeto.
    if ((risultato > 'z' && risultato <= 'z' + STEP) || (risultato > 'Z' && risultato <= 'Z' + STEP)) {
        risultato -= 26;
    }

    // Stampo la lettera convertita.
    printf("La lettera cifrata e' %c\n", risultato);

    return 0;
}
