#include <stdio.h>

enum Operazione {SOMMA, SOTTRAZIONE, MOLTIPLICAZIONE, DIVISIONE, EXIT};

int main() {
    int scelta;
    float x, y;

    do {
        // Stampo il menù.
        printf("Scegliere un'opzione:\n");
        printf("%d. Somma\n", SOMMA);
        printf("%d. Sottrazione\n", SOTTRAZIONE);
        printf("%d. Moltiplicazione\n", MOLTIPLICAZIONE);
        printf("%d. Divisione\n", DIVISIONE);
        printf("%d. Esci\n", EXIT);

        // Se non avessi voluto ripetere il menù alla fine di ogni operazione,
        // avrei fatto iniziare il do-while qui.

        // Chiedo di scegliere un'opzione.
        scanf("%d", &scelta);

        switch (scelta) {
            case SOMMA:
                printf("Inserire il primo valore: ");
                scanf("%f", &x);
                printf("Inserire il secondo valore: ");
                scanf("%f", &y);
                printf("Risultato: %f\n\n", x + y);
                break;

            case SOTTRAZIONE:
                printf("Inserire il primo valore: ");
                scanf("%f", &x);
                printf("Inserire il secondo valore: ");
                scanf("%f", &y);
                printf("Risultato: %f\n\n", x - y);
                break;

            case MOLTIPLICAZIONE:
                printf("Inserire il primo valore: ");
                scanf("%f", &x);
                printf("Inserire il secondo valore: ");
                scanf("%f", &y);
                printf("Risultato: %f\n\n", x * y);
                break;

            case DIVISIONE:
                printf("Inserire il primo valore: ");
                scanf("%f", &x);
                printf("Inserire il secondo valore: ");
                scanf("%f", &y);
                printf("Risultato: %f\n\n", x / y);
                break;
                
            case EXIT:
                // Bisogna gestire esplicitamente EXIT nello switch,
                // o si cadrebbe nell'azione di default.
                break;
                
            default:
                printf("Scelta non valida\n");
        }
    } while (scelta != EXIT);

    return 0;
}
