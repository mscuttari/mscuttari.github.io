#include <stdio.h>

#define CONV 1.60934

int main() {
    // Dichiarazione variabili.
    float valore, risultato;
    char scelta;

    // Chiedo un valore da convertire.
    printf("Inserisci un valore da convertire:\n");
    scanf("%f", &valore);
    scanf("%*c");

    // Chiedo il verso della conversione.
    printf("Inserisci il verso della conversione: m per miglia -> km, k per km -> miglia:\n");
    scanf("%c", &scelta);

    if (scelta == 'm') {
        // Da miglia a km.
        risultato = valore * CONV;
        
        // Stampo il risultato.
        printf("La distanza in km e' %f\n", risultato);
    } else if (scelta == 'k') {
        // Da km a miglia.
        risultato = valore / CONV;
        
        // Stampo il risultato.
        printf("La distanza in miglia e' %f\n", risultato);
    } else {
        printf("Scelta non valida!\n");
        return -1;
    }

    return 0;
}
