#include <stdio.h>

int main() {
    int risultato = 0;
    char c;

    scanf("%c", &c);

    while (c != '\n') {
        if (c < '0' || c > '9') {
            printf("Carattere non valido\n");
            return 1;
        }

        risultato *= 10;
        risultato += c - '0';
        scanf("%c", &c);
    }

    printf("Valore: %d\n", risultato);
    return 0;
}
