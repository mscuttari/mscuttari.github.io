#include <stdio.h>

int main() {
    int valore, somma = 0;

    // Chiedo il primo valore.
    printf("Inserire un valore: ");
    scanf("%d", &valore);

    // Incremento la somma e chiedo un valore fintanto che l'ultimo inserito è diverso da 0.
    while (valore != 0) {
        somma += valore;

        printf("Inserire un valore: ");
        scanf("%d", &valore);
    }

    /*
     * Possibile alternativa:
     *
     * int valore, somma = 0;
     *
     * do {
     *      printf("Inserire un valore: ");
     *      scanf("%d", &valore);
     *      somma += valore;
     * } while (valore != 0);
     */

    // Stampo la somma.
    printf("Somma: %d\n", somma);

    return 0;
}
