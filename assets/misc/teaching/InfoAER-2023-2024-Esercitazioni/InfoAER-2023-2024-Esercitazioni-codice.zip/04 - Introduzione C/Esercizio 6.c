#include <stdio.h>

int main() {
    float coefficiente, voto1, voto2, voto3;
    float voto;

    do {
        printf("Inserire il coefficiente di difficolta': ");
        scanf("%f", &coefficiente);
    } while (coefficiente < 0 || coefficiente > 4);

    do {
        printf("Inserire il primo voto: ");
        scanf("%f", &voto1);
    } while (voto1 < 0 || voto1 > 10);

    do {
        printf("Inserire il secondo voto: ");
        scanf("%f", &voto2);
    } while (voto2 < 0 || voto2 > 10);

    do {
        printf("Inserire il terzo voto: ");
        scanf("%f", &voto3);
    } while (voto3 < 0 || voto3 > 10);

    if (voto1 >= voto2 && voto1 <= voto3 ||
        voto1 >= voto3 && voto1 <= voto2) {
        voto = voto1 * coefficiente;
    } else if (voto2 >= voto1 && voto2 <= voto3 ||
               voto2 >= voto3 && voto2 <= voto1) {
        voto = voto2 * coefficiente;
    } else {
        voto = voto3 * coefficiente;
    }

    printf("Voto finale: %f\n", voto);
    return 0;
}
