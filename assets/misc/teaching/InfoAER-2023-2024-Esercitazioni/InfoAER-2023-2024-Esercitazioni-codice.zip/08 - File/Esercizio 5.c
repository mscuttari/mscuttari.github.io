#include <stdio.h>

void foo(FILE* in, FILE* out);

int main() {
    FILE* input = fopen("input", "rb");

    if (input == NULL) {
        printf("Impossibile aprire il file di input.\n");
        return -1;
    }

    FILE* output = fopen("output.txt", "w");

    if (output == NULL) {
        printf("Impossibile aprire il file di output.\n");
        fclose(input);
        return -1;
    }

    foo(input, output);

    fclose(input);
    fclose(output);
    return 0;
}

void foo(FILE* in, FILE* out) {
    int n, i;

    while (fread(&n, sizeof(int), 1, in) > 0) {
        fprintf(out, "%d\n", n);
    }
}
