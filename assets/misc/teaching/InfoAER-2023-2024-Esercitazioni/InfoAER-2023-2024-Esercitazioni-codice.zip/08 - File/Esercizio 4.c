#include <stdio.h>
#include <string.h>

#define RIGA_MAX 100

void contaLunghezzaRighe(FILE* in, FILE* out);

int main() {
    FILE* input = fopen("input.txt", "r");

    if (input == NULL) {
        printf("Impossibile aprire il file di input.\n");
        return -1;
    }

    FILE* output = fopen("output", "wb");

    if (output == NULL) {
        printf("Impossibile aprire il file di output.\n");
        fclose(input);
        return -1;
    }

    contaLunghezzaRighe(input, output);

    fclose(input);
    fclose(output);
    return 0;
}

void contaLunghezzaRighe(FILE* in, FILE* out) {
    // +1 per \n
    // +1 per il terminatore
    char buffer[RIGA_MAX + 2];

    // fgets legge fino a quando non incontra \n, o al più (RIGA_MAX + 2) - 1 caratteri.
    while (fgets(buffer, RIGA_MAX + 2, in) != NULL) {
        buffer[strcspn(buffer, "\n")] = '\0';
        int l = strlen(buffer);
        fwrite(&l, sizeof(int), 1, out);
    }
}
