#include <stdio.h>

void contaParole(FILE* in, FILE* out);

int main() {
    FILE* input = fopen("input.txt", "r");

    if (input == NULL) {
        printf("Impossibile aprire il file di input.\n");
        return -1;
    }

    FILE* output = fopen("output.txt", "w");

    if (output == NULL) {
        printf("Impossibile aprire il file di output.\n");
        fclose(input);
        return -1;
    }

    contaParole(input, output);

    fclose(input);
    fclose(output);
    return 0;
}

void contaParole(FILE* in, FILE* out) {
    char c;
    int i = 0;

    while ((c = getc(in)) != EOF) {
        if (c != ' ') {
            i++;
        } else {
            if (i > 0) {
                fprintf(out, "%d ", i);
                i = 0;
            }
        }
    }

    fprintf(out, "%d ", i);
}
