#include <stdio.h>

void foo(FILE* in, FILE* out);

int main() {
    FILE* input = fopen("input", "rb");

    if (input == NULL) {
        printf("Impossibile aprire il file di input.\n");
        return -1;
    }

    FILE* output = fopen("output", "wb+");

    if (output == NULL) {
        printf("Impossibile aprire il file di output.\n");
        fclose(input);
        return -1;
    }

    foo(input, output);

    fclose(input);
    fclose(output);

    return 0;
}

void foo(FILE* in, FILE* out) {
    int n;

    while (fread(&n, sizeof(int), 1, in) > 0) {
        if (n % 2 == 0) {
            fwrite(&n, sizeof(int), 1, out);
        }
    }

    int inizio, fine, x, y;
    inizio = 0;
    fseek(out, -sizeof(int), SEEK_END);
    fine = ftell(out);

    while (inizio < fine) {
        fseek(out, inizio, SEEK_SET);
        fread(&x, sizeof(int), 1, out);
        fseek(out, fine, SEEK_SET);
        fread(&y, sizeof(int), 1, out);

        fseek(out, inizio, SEEK_SET);
        fwrite(&y, sizeof(int), 1, out);
        fseek(out, fine, SEEK_SET);
        fwrite(&x, sizeof(int), 1, out);

        inizio += sizeof(int);
        fine -= sizeof(int);
    }
}
