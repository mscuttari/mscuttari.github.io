#include <stdio.h>

char nelMezzo(FILE *f);

int main() {
    FILE* f = fopen("input.txt", "r");

    if (f == NULL) {
        printf("Impossibile aprire il file.\n");
        return -1;
    }

    printf("Carattere: %c\n", nelMezzo(f));
    fclose(f);

    return 0;
}

char nelMezzo(FILE *f) {
    char c;
    fseek(f, 0, SEEK_END);
    long dim = ftell(f);

    fseek(f, (dim - 1) / 2, SEEK_SET);
    fscanf(f, "%c", &c);

    return c;
}
