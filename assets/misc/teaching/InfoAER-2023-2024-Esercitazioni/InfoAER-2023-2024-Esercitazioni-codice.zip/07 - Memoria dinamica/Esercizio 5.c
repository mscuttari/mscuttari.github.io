#include <stdio.h>
#include <stdlib.h>

// La funzione riceve il numero di righe del triangolo di Tartaglia che si
// desidera costruire e ritorna il numero totale di elementi.
int calcola_numero_totale_elementi(int righe);

// La funzione riceve il puntatore all'inizio della memoria dedicata ai valori
// del triangolo di Tartaglia e la riga desiderata (la numerazione inizia da 1).
// Ritorna il puntatore al primo elemento della riga indicata.
int* ottieni_riga(int* valori, int riga);

// La funzione riceve il puntatore all'inizio della memoria dedicata ai valori
// del triangolo di Tartaglia e il numero della riga da popolare (la
// numerazione inizia da 1).
// Al termine dell'esecuzione della funzione, la riga sarà popolata con gli
// opportuni valori.
void popola_riga(int* valori, int riga);

int main() {
    int n;

    printf("Inserire il numero di righe: ");
    scanf("%d", &n);

    // Allocazione della memoria.
    int numero_elementi = calcola_numero_totale_elementi(n);
    int* valori = (int*) malloc(numero_elementi * sizeof(int));
    
    if (valori == NULL) {
        return -1;
    }

    // Inserimento dei valori.
    for (int i = 1; i <= n; ++i) {
        popola_riga(valori, i);
    }

    // Stampa dei valori.
    for (int i = 1; i <= n; ++i) {
        int* riga = ottieni_riga(valori, i);

        for (int j = 0; j < i; ++j) {
            printf("%d\t", riga[j]);
        }

        printf("\n");
    }
    
    // Deallocazione della memoria.
    free(valori);

    return 0;
}

int calcola_numero_totale_elementi(int righe) {
    // Il numero totale di elementi per n righe è uguale alla somma dei primi n
    // numeri interi. Per effettuare questo calcolo si può usare la formula di
    // Gauss.

    return righe * (righe + 1) / 2;
}

int* ottieni_riga(int* valori, int riga) {
    if (riga == 1)
        return valori;

    return valori + calcola_numero_totale_elementi(riga - 1);
}

void popola_riga(int* valori, int n) {
    int* riga_corrente = ottieni_riga(valori, n);

    riga_corrente[0] = 1;
    riga_corrente[n - 1] = 1;

    if (n > 2) {
        int* riga_precedente = ottieni_riga(valori, n - 1);

        for (int i = 1; i < n - 1; ++i) {
            riga_corrente[i] = riga_precedente[i - 1] + riga_precedente[i];
        }
    }
}
