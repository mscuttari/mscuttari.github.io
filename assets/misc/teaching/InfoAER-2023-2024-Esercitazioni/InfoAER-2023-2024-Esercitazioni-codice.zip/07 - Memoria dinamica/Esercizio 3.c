#include <stdio.h>
#include <stdlib.h>

float* leggi_matrice(int d1, int d2);
float* trasponi(float* mat, int d1, int d2);
void stampa_matrice(float* m, int d1, int d2);

int main() {
    int n, m;
    float *mat;

    printf("Trasposta di una matrice NxM\n");

    printf("Inserire N: ");
    scanf("%d", &n);

    printf("Inserire M: ");
    scanf("%d", &m);

    // Lettura della matrice sorgente.
    mat = leggi_matrice(n, m);

    if (mat == NULL) {
        return -1;
    }

    // Calcolo della matrice trasposta.
    float* ris = trasponi(mat, n, m);

    if (ris == NULL) {
        // Prime di terminare il programma, è necessario deallocare la memoria
        // assegnata alla matrice di partenza.
        free(mat);
        return -1;
    }

    printf("Matrice originale:\n");
    stampa_matrice(mat, n, m);

    printf("Matrice trasposta:\n");
    stampa_matrice(ris, m, n);
    
    free(mat);
    free(ris);

    return 0;
}

float* leggi_matrice(int d1, int d2) {
    float* m = (float*) malloc(d1 * d2 * sizeof(float));
    
    if (m != NULL) {
        printf("Inserire i valori della matrice.\n");
        
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d2; ++j) {
                printf("Inserire il valore in posizione [%d][%d]: ", i, j);
                scanf("%f", m + i * d2 + j);
            }
        }
    }
    
    return m;
}

float* trasponi(float* mat, int d1, int d2) {
    float* ris = (float*) malloc(d1 * d2 * sizeof(float));

    if (ris != NULL) {
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d2; ++j) {
                *(ris + j * d1 + i) = *(mat + i * d2 + j);
            }
        }
    }

    return ris;
}

void stampa_matrice(float* m, int d1, int d2) {
    for (int i = 0; i < d1; ++i) {
        for (int j = 0; j < d2; ++j) {
            printf("%.2f\t", *(m + i * d2 + j));
        }
        printf("\n");
    }
}
