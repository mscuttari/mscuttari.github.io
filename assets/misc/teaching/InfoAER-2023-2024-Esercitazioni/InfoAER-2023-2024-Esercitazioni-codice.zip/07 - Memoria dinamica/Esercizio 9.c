#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

char* leggi_stringa(char* buffer);
char* cerca_candidata(char* str, char** stringhe, int n);

int main() {
    char buf[MAX];
    char** stringhe;
    int n;

    // Creazione dell'array contenente i puntatori alle stringhe.
    printf("Inserire il numero di stringhe: ");
    scanf("%d", &n);

    stringhe = (char**) malloc(n * sizeof(char*));

    if (stringhe == NULL) {
        return -1;
    }
    
    for (int i = 0; i < n; ++i) {
        stringhe[i] = NULL;
    }

    // Lettura delle stringhe.
    for (int i = 0; i < n; ++i) {
        do {
            if (stringhe[i] != NULL) {
                free(stringhe[i]);
            }
            
            printf("Inserire una stringa da 3 o più caratteri (stringa %d di %d): ", i + 1, n);
            stringhe[i] = leggi_stringa(buf);
            
            if (stringhe[i] == NULL) {
                return -1;
            }
        } while (strlen(stringhe[i]) < 3);
    }

    // Modifica (se necessario) di una stringa alla volta.
    for (int i = 0; i < n - 1; ++i) {
        char* candidata = cerca_candidata(stringhe[i], stringhe + i + 1, n - 1 - i);

        if (candidata != NULL) {
            // E' stata trovata una stringa da concatenare (eccetto i primi due
            // caratteri) alla stringa corrente. Per farlo, è però necessario
            // creare una stringa che abbia un numero sufficiente di caratteri.

            int l1 = strlen(stringhe[i]);
            int l2 = strlen(candidata + 2);
            char* tmp = (char*) malloc((l1 + l2 + 1) * sizeof(char));

            // Copia della prima stringa in quella nuova.
            strcpy(tmp, stringhe[i]);

            // Concatenazione della seconda stringa, partendo dal suo terzo
            // carattere.
            strcat(tmp, candidata + 2);

            // Deallocazione della vecchia stringa.
            free(stringhe[i]);

            // Salvataggio del puntatore alla stringa estesa.
            stringhe[i] = tmp;
        }
    }

    // Stampa delle nuove stringhe.
    for (int i = 0; i < n; ++i) {
        printf("%s\n", stringhe[i]);
    }
    
    // Deallocazione della memoria.
    for (int i = 0; i < n; ++i) {
        free(stringhe[i]);
    }
    
    free(stringhe);

    return 0;
}

char* leggi_stringa(char* buffer) {
    scanf("%s", buffer);

    char* ris = (char*) malloc((strlen(buffer) + 1) * sizeof(char));

    if (ris != NULL) {
        strcpy(ris, buffer);
    }

    return ris;
}

char* cerca_candidata(char* str, char** stringhe, int n) {
    int l1 = strlen(str);

    for (int i = 0; i < n ; ++i) {
        if (str[l1 - 2] == stringhe[i][0] && str[l1 - 1] == stringhe[i][1]) {
            return stringhe[i];
        }
    }

    return NULL;
}
