#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

char* stringa_senza_carattere(char* str, char c);

int main() {
    char str[MAX];
    char c;

    printf("Inserire una parola: ");
    scanf("%s%*c", str);

    printf("Inserire il carattere da rimuovere: ");
    scanf("%c", &c);

    char* ris = stringa_senza_carattere(str, c);

    if (ris == NULL) {
        return -1;
    }

    printf("%s\n", ris);
    free(ris);

    return 0;
}

char* stringa_senza_carattere(char* str, char c) {
    int occorrenze = 0;
    int l = strlen(str);
    
    for (int i = 0; i < l; ++i) {
        if (str[i] == c) {
            ++occorrenze;
        }
    }
    
    char* ris = (char*) malloc((l - occorrenze + 1) * sizeof(char));
    
    int pos = 0;

    for (int i = 0; i < strlen(str); ++i) {
        if (str[i] != c) {
            ris[pos++] = str[i];
        }
    }
    
    ris[pos] = '\0';

    return ris;
}
