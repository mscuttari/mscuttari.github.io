#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

char* leggi_stringa(char* buffer);
char* concatena(char* str1, char* str2);

int main() {
    // Buffer in cui salvare temporaneamente le stringhe lette da stdin.
    char buf[MAX];

    char *str1, *str2;

    // Lettura della prima stringa, allocazione della memoria necessaria per il
    // suo salvataggio, e copia.
    printf("Inserire la prima stringa: ");
    str1 = leggi_stringa(buf);

    if (str1 == NULL) {
        return -1;
    }

    // Lettura della seconda stringa, allocazione della memoria necessaria per
    // il suo salvataggio, e copia.
    printf("Inserire la seconda stringa: ");
    str2 = leggi_stringa(buf);

    if (str2 == NULL) {
        free(str1);
        return -1;
    }

    // Concatenazione.
    char* str3 = concatena(str1, str2);

    if (str3 == NULL) {
        free(str1);
        free(str2);
        return -1;
    }

    printf("Stringa 1: %s\n", str1);
    printf("Stringa 2: %s\n", str2);
    printf("Concatenazione: %s\n", str3);
    
    // Deallocazione della memoria.
    free(str1);
    free(str2);
    free(str3);

    return 0;
}

char* leggi_stringa(char* buffer) {
    scanf("%s", buffer);

    char* ris = (char*) malloc((strlen(buffer) + 1) * sizeof(char));

    if (ris != NULL) {
        strcpy(ris, buffer);
    }

    return ris;
}

char* concatena(char* str1, char* str2) {
    int l1 = strlen(str1);
    int l2 = strlen(str2);

    char* ris = (char*) malloc((l1 + l2 + 1) * sizeof(char));

    if (ris != NULL) {
        strcpy(ris, str1);
        strcpy(ris + l1, str2);
    }

    return ris;
}
