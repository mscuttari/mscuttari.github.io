#include <stdio.h>
#include <stdlib.h>

float* leggi_matrice(int d1, int d2);
float* somma_matrici(float* m1, float* m2, int d1, int d2);
void stampa_matrice(float* m, int d1, int d2);

int main() {
    int n, m;

    printf("Somma di due matrici NxM\n");

    printf("Inserire N: ");
    scanf("%d", &n);

    printf("Inserire M: ");
    scanf("%d", &m);

    // Lettura della prima matrice.
    float* m1 = leggi_matrice(n, m);
    
    if (m1 == NULL) {
        return -1;
    }

    // Lettura della seconda matrice.
    float* m2 = leggi_matrice(n, m);

    if (m2 == NULL) {
        // Prime di terminare il programma, è necessario deallocare la memoria
        // assegnata a m1.
        free(m1);
        return -1;
    }

    // Calcolo del risultato.
    float* ris = somma_matrici(m1, m2, n, m);

    if (ris == NULL) {
        // Prime di terminare il programma, è necessario deallocare la memoria
        // assegnata a m1 e m2.
        free(m1);
        free(m2);
        return 1;
    }

    // Stampa delle matrici.
    printf("Prima matrice:\n");
    stampa_matrice(m1, n, m);

    printf("Seconda matrice:\n");
    stampa_matrice(m2, n, m);

    printf("Risultato:\n");
    stampa_matrice(ris, n, m);

    // Deallocazione della memoria.
    free(m1);
    free(m2);
    free(ris);

    return 0;
}

float* leggi_matrice(int d1, int d2) {
    float* m = (float*) malloc(d1 * d2 * sizeof(float));
    
    if (m != NULL) {
        printf("Inserire i valori della matrice.\n");
        
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d2; ++j) {
                printf("Inserire il valore in posizione [%d][%d]: ", i, j);
                scanf("%f", m + i * d2 + j);
            }
        }
    }
    
    return m;
}

float* somma_matrici(float* m1, float* m2, int d1, int d2) {
    float* ris = (float*) malloc(d1 * d2 * sizeof(float));

    if (ris != NULL) {
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d2; ++j) {
                *(ris + i * d2 + j) = *(m1 + i * d2 + j) + *(m2 + i * d2 + j);
            }
        }
    }

    return ris;
}

void stampa_matrice(float* m, int d1, int d2) {
    for (int i = 0; i < d1; ++i) {
        for (int j = 0; j < d2; ++j) {
            printf("%.2f\t", *(m + i * d2 + j));
        }

        printf("\n");
    }
}
