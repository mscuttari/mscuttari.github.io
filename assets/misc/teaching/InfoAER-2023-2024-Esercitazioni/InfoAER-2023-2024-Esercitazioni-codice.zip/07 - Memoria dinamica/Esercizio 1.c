#include <stdio.h>
#include <stdlib.h>

float* leggi_array(int n);
float somma(float* a, int n);

int main() {
    int n;
    float* valori;

    printf("Inserire il numero di valori: ");
    scanf("%d", &n);

    // Lettura dei valori.
    valori = leggi_array(n);
    
    if (valori == NULL) {
        return -1;
    }

    // Calcolo della somma.
    float risultato = somma(valori, n);
    printf("La somma vale %.2f.\n", risultato);

    // Deallocazione della memoria.
    free(valori);

    return 0;
}

float* leggi_array(int n) {
    float* valori = (float*) malloc(n * sizeof(float));

    if (valori != NULL) {
        for (int i = 0; i < n; ++i) {
            printf("Inserire un valore (%d di %d): ", i + 1, n);
            scanf("%f", valori + i);
        }
    }
    
    return valori;
}

float somma(float* a, int n) {
    float ris = 0;

    for (int i = 0; i < n; ++i) {
        ris += a[i];
    }

    return ris;
}
