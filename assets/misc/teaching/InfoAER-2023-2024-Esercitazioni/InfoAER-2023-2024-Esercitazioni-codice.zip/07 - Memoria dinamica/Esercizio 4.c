#include <stdio.h>
#include <stdlib.h>

float* leggi_matrice(int d1, int d2);
float* prodotto_matrici(float* m1, float* m2, int d1, int d2, int d3);
void stampa_matrice(float* m, int d1, int d2);

int main() {
    int n, m, p;
    float *m1, *m2;

    printf("Prodotto tra due matrici NxM e MxP\n");

    printf("Inserire N: ");
    scanf("%d", &n);

    printf("Inserire M: ");
    scanf("%d", &m);

    printf("Inserire P: ");
    scanf("%d", &p);

    // Lettura della prima matrice.
    m1 = leggi_matrice(n, m);

    if (m1 == NULL) {
        return -1;
    }

    // Lettura della seconda matrice.
    m2 = leggi_matrice(m, p);

    if (m2 == NULL) {
        // Prime di terminare il programma, è necessario deallocare la memoria
        // assegnata a m1.
        free(m1);
        return 1;
    }

    // Calcolo del risultato.
    float* ris = prodotto_matrici(m1, m2, n, m, p);

    if (ris == NULL) {
        // Prime di terminare il programma, è necessario deallocare la memoria
        // assegnata a m1 e m2.
        free(m1);
        free(m2);
        return 1;
    }

    // Stampa delle matrici.
    printf("Prima matrice:\n");
    stampa_matrice(m1, n, m);

    printf("Seconda matrice:\n");
    stampa_matrice(m2, m, p);

    printf("Risultato:\n");
    stampa_matrice(ris, n, p);

    // Deallocazione della memoria.
    free(m1);
    free(m2);
    free(ris);

    return 0;
}

float* leggi_matrice(int d1, int d2) {
    float* m = (float*) malloc(n * m * sizeof(float));
    
    if (m != NULL) {
        printf("Inserire i valori della matrice.\n");
        
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d2; ++j) {
                printf("Inserire il valore in posizione [%d][%d]: ", i, j);
                scanf("%f", m + i * d2 + j);
            }
        }
    }
    
    return m;
}

float* prodotto_matrici(float* m1, float* m2, int d1, int d2, int d3) {
    float* ris = (float*) malloc(d1 * d3 * sizeof(float));

    if (ris != NULL) {
        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d3; ++j) {
                *(ris + i * d3 + j) = 0;
            }
        }

        for (int i = 0; i < d1; ++i) {
            for (int j = 0; j < d3; ++j) {
                for (int k = 0; k < d2; ++k) {
                    // ris[i][j] += m1[i][k] * m2[k][j]
                    *(ris + i * d3 + j) += *(m1 + i * d2 + k) * *(m2 + k * d3 + j);
                }
            }
        }
    }

    return ris;
}

void stampa_matrice(float* m, int d1, int d2) {
    for (int i = 0; i < d1; ++i) {
        for (int j = 0; j < d2; ++j) {
            printf("%.2f\t", *(m + i * d2 + j));
        }

        printf("\n");
    }
}
