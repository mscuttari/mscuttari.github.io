#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

char* somma(char* x, char* y);
char* estendi(char* str, int l);

int main() {
    char x[MAX];
    char y[MAX];

    printf("Inserire il primo valore: ");
    scanf("%s", x);

    printf("Inserire il secondo valore: ");
    scanf("%s", y);

    char* ris = somma(x, y);

    if (ris == NULL) {
        return -1;
    }

    printf("Risultato: %s\n", ris);
    
    free(ris);

    return 0;
}

char* somma(char* str1, char* str2) {
	/*
    // Per la soluzione dell'esercizio esteso, abilitare queste righe.
    for (int i = 0; str1[i] == '0' && str1[i] != '\0'; ++i) {
        ++str1;
    }
    
    for (int i = 0; str2[i] == '0' && str2[i] != '\0'; ++i) {
        ++str2;
    }
	*/
    
    // Soluzione esercizio base (verde).
    int l1 = strlen(str1);
    int l2 = strlen(str2);

    int maxLen = l1 > l2 ? l1 : l2;

    // Ottenimento di stringhe con la stessa lunghezza (il numero più corto è
    // allineato a destra).
    char* str1_est = estendi(str1, maxLen);

    if (str1_est == NULL) {
        return NULL;
    }

    char* str2_est = estendi(str2, maxLen);

    if (str2_est == NULL) {
        free(str1_est);
        return NULL;
    }

    // Allocazione della memoria per il risultato.
    char* ris = (char*) malloc((maxLen + 1) * sizeof(char));

    if (ris == NULL) {
        free(str1_est);
        free(str2_est);
        return NULL;
    }

    ris[maxLen] = '\0';

    // Variabile per il riporto ottenuto dall'ultima somma.
    int riporto = 0;

    for (int i = 0; i < maxLen; ++i) {
        int x = str1_est[maxLen - i - 1] - '0';
        int y = str2_est[maxLen - i - 1] - '0';
        int s = x + y + riporto;

        riporto = 0;

        if (s >= 10) {
            s -= 10;
            ++riporto;
        }

        ris[maxLen - i - 1] = s + '0';
    }

    // Le stringhe estese non servono più.
    free(str1_est);
    free(str2_est);

    // Se il riporto non è 0, allora la stringa del risultato ha bisogno di una
    // cella in più a sinistra.
    if (riporto != 0) {
        char* tmp = (char*) malloc((strlen(ris) + 1 + 1) * sizeof(char));

        if (tmp != NULL) {
            tmp[0] = riporto + '0';
            strcpy(tmp + 1, ris);
        }

        free(ris);
        ris = tmp;
    }

    return ris;
}

char* estendi(char* str, int l) {
    char* ris = (char*) malloc((l + 1) * sizeof(char));

    if (ris != NULL) {
        for (int i = 0; i < l; ++i) {
            ris[i] = '0';
        }

        ris[l] = '\0';
        strcpy(ris + l - strlen(str), str);
    }

    return ris;
}
