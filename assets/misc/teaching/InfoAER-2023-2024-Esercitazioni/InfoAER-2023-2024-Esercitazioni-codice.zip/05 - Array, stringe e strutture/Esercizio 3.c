#include <stdio.h>

#define N 3

int main() {
    int matrice[N][N];

    // 1 se la matrice è simmetrica, 0 se non lo è.
    int simmetrica = 1;

    // Chiedo i valori della matrice.
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            printf("Inserire il valore di [%d,%d]: ", i, j);
            scanf("%d", &matrice[i][j]);
        }
    }

    // Controllo se la matrice è simmetrica.
    // Nella condizione controllo anche il valore di 'simmetrica'. Se ho
    // trovato una posizione non valida non ha senso continuare a iterare.
    // Inoltre, il ciclo più intero itera fino a 'i' (e non 'N') per
    // risparmiare la metà del tempo.
    for (int i = 0; simmetrica && i < N; ++i) {
        for (int j = 0; simmetrica && j < i; ++j) {
            if (matrice[i][j] != matrice[j][i])
                simmetrica = 0;
        }
    }

    // Stampo il risultato.
    if (simmetrica) {
        printf("La matrice è simmetrica.\n");
    } else {
        printf("La matrice non è simmetrica.\n");
    }

    return 0;
}
