#include <stdio.h>

#define N 10

#define MAX_MARCA 30
#define MAX_MODELLO 30
#define MAX_TARGA 7

typedef struct {
    int giorno;
    int mese;
    int anno;
} data_t;

typedef enum {benzina, gasolio, metano, gpl, elettrico} tipologia_motore_t;

typedef struct {
    char marca[MAX_MARCA];
    char modello[MAX_MODELLO];
    char targa[MAX_TARGA];
    data_t immatricolazione;
    tipologia_motore_t motore;
} auto_t;

int main() {
    auto_t vetture[N];

    // Variabile temporanea per convertire da int a enum.
    int motore;

    data_t soglia;

    for (int i = 0; i < N; ++i) {
        // Chiedo i dati dell'auto corrente
        printf("Inserire i dati dell'auto #%d\n", i);

        printf("Marca: ");
        scanf("%s", vetture[i].marca);
        // Meglio: fgets(vetture[i].marca, MAX_MARCA, stdin);

        printf("Modello: ");
        scanf("%s", vetture[i].modello);

        printf("Targa: ");
        scanf("%s", vetture[i].targa);

        printf("Data di immatricolazione (dd/mm/yyyy): ");
        scanf("%d/%d/%d", &vetture[i].immatricolazione.giorno, &vetture[i].immatricolazione.mese, &vetture[i].immatricolazione.anno);

        printf("Tipologia motore (%d: benzina, %d: gasolio, %d: metano, %d: gpl, %d: elettrico): ", benzina, gasolio, metano, gpl, elettrico);
        scanf("%d", &motore);

        if (motore == benzina) {
            vetture[i].motore = benzina;
        } else if (motore == gasolio) {
            vetture[i].motore = gasolio;
        } else if (motore == metano) {
            vetture[i].motore = metano;
        } else if (motore == gpl) {
            vetture[i].motore = gpl;
        } else if (motore == elettrico) {
            vetture[i].motore = elettrico;
        } else {
            printf("Scelta non valida!\n");
            return -1;
        }
    }

    // Chiedo la data oltre la quale stampare i dati dell'auto.
    printf("Inserire una data (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &soglia.giorno, &soglia.mese, &soglia.anno);

    // Itero sull'array delle auto e stampo quelle con data di immatricolazione
    // successiva alla data appena inserita.

    for (int i = 0; i < N; ++i) {
        if (vetture[i].immatricolazione.anno > soglia.anno ||
        (vetture[i].immatricolazione.anno == soglia.anno && vetture[i].immatricolazione.mese > soglia.mese) ||
        (vetture[i].immatricolazione.anno == soglia.anno && vetture[i].immatricolazione.mese == soglia.mese && vetture[i].immatricolazione.giorno > soglia.giorno)) {
            printf("Marca: %s\n", vetture[i].marca);
            printf("Modello: %s\n", vetture[i].modello);
            printf("Targa: %s\n", vetture[i].targa);

            printf("Immatricolazione: %d/%d/%d\n", vetture[i].immatricolazione.giorno, vetture[i].immatricolazione.mese, vetture[i].immatricolazione.anno);

            printf("Tipologia motore: ");

            if (vetture[i].motore == benzina) {
                printf("benzina\n");
            } else if (vetture[i].motore == gasolio) {
                printf("gasolio\n");
            } else if (vetture[i].motore == metano) {
                printf("metano\n");
            } else if (vetture[i].motore == gpl) {
                printf("gpl\n");
            } else if (vetture[i].motore == elettrico) {
                printf("elettrico\n");
            }

            printf("\n");
        }
    }

    return 0;
}
