#define MAX_NOME 40
#define MAX_COGNOME 40
#define MAX_TITOLO 60
#define MAX_ISBN 14

struct Data {
    int giorno;
    int mese;
    int anno;
};

struct Persona {
    char nome[MAX_NOME];
    char cognome[MAX_COGNOME];
};

struct Libro {
    char titolo[MAX_TITOLO];
    char isbn[MAX_ISBN];
    struct Data pubblicazione;
    struct Persona autore;
};

/*
Usando typedef:
 
typedef struct {
    int giorno;
    int mese;
    int anno;
} data_t;

typedef struct {
    char nome[MAX_NOME];
    char cognome[MAX_COGNOME];
} persona_t;

typedef struct {
    char titolo[MAX_TITOLO];
    char isbn[MAX_ISBN];
    data_t pubblicazione;
    persona_t autore;
} libro_t;
 */
