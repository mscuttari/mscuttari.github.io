#include <stdio.h>

#define N 100

int main() {
    int valori[N];
    int letti = 0;
    int soglia;

    for (int i = 0; i < N; ++i) {
        // Chiedo il prossimo valore.
        printf("Inserire un valore (0 per terminare l'inserimento): ");
        scanf("%d", &valori[i]);

        // Se il valore è 0, termino la lettura.
        if (valori[i] == 0)
            break;

        // Incremento il contatore dei numeri letti.
        ++letti;
    }

    // Chiedo il valore di soglia.
    printf("Inserire il valore di soglia: ");
    scanf("%d", &soglia);

    // Stampo i valori più grandi di 'soglia'.
    printf("I valori più grandi di %d sono:\n", soglia);

    for (int i = 0; i < letti; ++i) {
        if (valori[i] > soglia)
            printf("%d\n", valori[i]);
    }

    return 0;
}

/*
Soluzione alternativa: non tengo traccia di quanti numeri ho letto, e quando
controllo i valori sopra la soglia mi fermo appena incontro 0.

int main() {
    int valori[N];
    int soglia;

    for (int i = 0; i < N; ++i) {
        // Chiedo il prossimo valore.
        printf("Inserire un valore (0 per terminare l'inserimento): ");
        scanf("%d", &valori[i]);

        // Se il valore è 0, termino la lettura.
        if (valori[i] == 0)
            break;
    }

    // Chiedo il valore di soglia.
    printf("Inserire il valore di soglia: ");
    scanf("%d", &soglia);

    // Stampo i valori più grandi di 'soglia'.
    printf("I valori più grandi di %d sono:\n", soglia);

    for (int i = 0; i < N; ++i) {
        if (valori[i] == 0)
            break;

        if (valori[i] > soglia)
            printf("%d\n", valori[i]);
    }

    return 0;
}
 */
