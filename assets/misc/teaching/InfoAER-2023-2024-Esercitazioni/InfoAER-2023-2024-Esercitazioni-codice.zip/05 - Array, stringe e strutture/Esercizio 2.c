#include <stdio.h>

#define N 5

int main() {
    int v[N];

    // Chiedo i valori.
    printf("Inserire %d valori:\n", N);

    for (int i = 0; i < N; ++i) {
        scanf("%d", &v[i]);
    }

    // Applico il Bubble sort.
    for (int i = 0; i < N - 1; ++i) {
        for (int j = 0; j < N - i - 1; ++j) {
            if (v[j] > v[j + 1]) {
                int tmp = v[j];
                v[j] = v[j + 1];
                v[j + 1] = tmp;
            }
        }
    }

    // Stampo i valori.
    printf("Valori ordinati: ");

    for (int i = 0; i < N; ++i) {
        printf("%d ", v[i]);
    }

    return 0;
}
