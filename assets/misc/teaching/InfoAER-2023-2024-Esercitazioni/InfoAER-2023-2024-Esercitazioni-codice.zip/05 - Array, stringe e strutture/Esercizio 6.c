#include <stdio.h>
#include <string.h>

#define MAX 100

int main() {
    char str[MAX];
    int palindroma = 1;

    printf("Inserire la stringa: ");
    scanf("%s", str);

    int n = strlen(str);

    // char s[] = "ANNA"
    // s[0] = 'A'
    // s[1] = 'N'
    // s[2] = 'N'
    // s[3] = 'A'
    // s[4] = '\0'

    // strlen(s) = 4

    for (int i = 0; palindroma && i < n / 2; ++i) {
        if (str[i] != str[n - i - 1]) {
            palindroma = 0;
        }
    }

    if (palindroma) {
        printf("La parola è palindroma.\n");
    } else {
        printf("La parola non è palindroma.\n");
    }

    return 0;
}
